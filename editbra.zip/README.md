# 🎬 Editbra

## 📋 Requisitos
- Node.js (versión 14 o superior)
- npm (incluido con Node.js)

## 🚀 Instalación

1. **Instalar Node.js** desde [nodejs.org](https://nodejs.org/)

2. **Crear la estructura de carpetas:**
```bash
mkdir video-downloader
cd video-downloader