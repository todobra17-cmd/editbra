const express = require('express');
const cors = require('cors');
const ytdl = require('ytdl-core');
const ytsr = require('ytsr');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { spawn } = require('child_process');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// Configurar multer para subida de archivos
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Obtener información del video de YouTube
app.post('/api/video-info', async (req, res) => {
    try {
        const { url } = req.body;
        const videoId = extractVideoId(url);
        
        if (!videoId) {
            return res.status(400).json({ error: 'URL de YouTube no válida' });
        }

        const info = await ytdl.getInfo(videoId);
        
        const videoDetails = {
            id: videoId,
            title: info.videoDetails.title,
            author: info.videoDetails.author.name,
            duration: info.videoDetails.lengthSeconds,
            thumbnail: info.videoDetails.thumbnails[info.videoDetails.thumbnails.length - 1].url,
            formats: info.formats
                .filter(format => format.hasVideo || format.hasAudio)
                .map(format => ({
                    itag: format.itag,
                    quality: format.qualityLabel || format.audioBitrate + 'kbps',
                    mimeType: format.mimeType,
                    hasVideo: format.hasVideo,
                    hasAudio: format.hasAudio,
                    container: format.container,
                    contentLength: format.contentLength
                }))
        };

        res.json(videoDetails);
    } catch (error) {
        console.error('Error obteniendo información del video:', error);
        res.status(500).json({ error: 'Error al obtener información del video' });
    }
});

// Descargar video de YouTube
app.post('/api/download', async (req, res) => {
    try {
        const { url, format = 'mp4', quality = 'highest' } = req.body;
        const videoId = extractVideoId(url);
        
        if (!videoId) {
            return res.status(400).json({ error: 'URL de YouTube no válida' });
        }

        const info = await ytdl.getInfo(videoId);
        const title = info.videoDetails.title.replace(/[^\w\s]/gi, '');
        
        let formatOptions = {};
        
        switch (format) {
            case 'mp3':
                formatOptions = {
                    filter: 'audioonly',
                    quality: 'highestaudio'
                };
                break;
            case 'mp4':
                formatOptions = {
                    filter: 'videoandaudio',
                    quality: quality === 'highest' ? 'highest' : quality
                };
                break;
            case 'webm':
                formatOptions = {
                    filter: 'videoandaudio',
                    quality: quality === 'highest' ? 'highest' : quality
                };
                break;
            default:
                formatOptions = {
                    filter: 'videoandaudio',
                    quality: 'highest'
                };
        }

        res.setHeader('Content-Disposition', `attachment; filename="${title}.${format}"`);
        res.setHeader('Content-Type', getContentType(format));

        const stream = ytdl(videoId, formatOptions);
        stream.pipe(res);

        stream.on('error', (error) => {
            console.error('Error en la descarga:', error);
            if (!res.headersSent) {
                res.status(500).json({ error: 'Error en la descarga' });
            }
        });

    } catch (error) {
        console.error('Error en la descarga:', error);
        res.status(500).json({ error: 'Error al descargar el video' });
    }
});

// Buscar videos de YouTube
app.get('/api/search', async (req, res) => {
    try {
        const { query } = req.query;
        if (!query) {
            return res.status(400).json({ error: 'Se requiere un término de búsqueda' });
        }

        const filters = await ytsr.getFilters(query);
        const filter = filters.get('Type').find(f => f.name === 'Video');
        const searchResults = await ytsr(filter.ref, { limit: 10 });

        const videos = searchResults.items.map(item => ({
            id: item.id,
            title: item.title,
            author: item.author?.name,
            duration: item.duration,
            thumbnail: item.bestThumbnail?.url,
            url: item.url
        }));

        res.json(videos);
    } catch (error) {
        console.error('Error en la búsqueda:', error);
        res.status(500).json({ error: 'Error en la búsqueda' });
    }
});

// Subir archivo de video
app.post('/api/upload', upload.single('video'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No se subió ningún archivo' });
        }

        res.json({
            filename: req.file.filename,
            originalName: req.file.originalname,
            size: req.file.size,
            path: `/uploads/${req.file.filename}`
        });
    } catch (error) {
        console.error('Error subiendo archivo:', error);
        res.status(500).json({ error: 'Error al subir el archivo' });
    }
});

// Servir archivos subidos
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Convertir video a MP3 usando ffmpeg (si está instalado)
app.post('/api/convert-to-mp3', async (req, res) => {
    try {
        const { url } = req.body;
        const videoId = extractVideoId(url);
        
        if (!videoId) {
            return res.status(400).json({ error: 'URL de YouTube no válida' });
        }

        const info = await ytdl.getInfo(videoId);
        const title = info.videoDetails.title.replace(/[^\w\s]/gi, '');
        const outputPath = path.join(__dirname, 'downloads', `${title}.mp3`);

        // Crear directorio de descargas si no existe
        if (!fs.existsSync(path.join(__dirname, 'downloads'))) {
            fs.mkdirSync(path.join(__dirname, 'downloads'));
        }

        // Usar ffmpeg para convertir
        const ffmpeg = spawn('ffmpeg', [
            '-i', 'pipe:0',
            '-vn',
            '-acodec', 'libmp3lame',
            '-ab', '192k',
            '-ar', '44100',
            outputPath
        ]);

        const stream = ytdl(videoId, { filter: 'audioonly', quality: 'highestaudio' });
        stream.pipe(ffmpeg.stdin);

        ffmpeg.on('close', (code) => {
            if (code === 0) {
                res.download(outputPath, `${title}.mp3`, (err) => {
                    if (err) {
                        console.error('Error descargando MP3:', err);
                    }
                    // Limpiar archivo temporal
                    fs.unlink(outputPath, () => {});
                });
            } else {
                res.status(500).json({ error: 'Error en la conversión a MP3' });
            }
        });

    } catch (error) {
        console.error('Error convirtiendo a MP3:', error);
        res.status(500).json({ error: 'Error en la conversión' });
    }
});

// Función para extraer ID de YouTube
function extractVideoId(url) {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
        /^([a-zA-Z0-9_-]{11})$/
    ];
    
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
            return match[1];
        }
    }
    return null;
}

// Función para obtener el tipo de contenido
function getContentType(format) {
    const types = {
        'mp4': 'video/mp4',
        'webm': 'video/webm',
        'mp3': 'audio/mpeg',
        'm4a': 'audio/mp4',
        '3gp': 'video/3gpp'
    };
    return types[format] || 'application/octet-stream';
}

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
    console.log('📁 Archivos servidos desde:', __dirname);
    console.log('🎬 Descargador de videos listo para usar');
});